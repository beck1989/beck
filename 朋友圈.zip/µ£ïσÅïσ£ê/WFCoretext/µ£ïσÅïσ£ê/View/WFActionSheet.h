//
//  WFActionSheet.h
//  WFCoretext
//
//  Created by 阿虎 on 15/5/12.
//  Copyright (c) 2015年 tigerwf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WFActionSheet : UIActionSheet

@property (nonatomic, assign)NSInteger actionIndex;

@end
