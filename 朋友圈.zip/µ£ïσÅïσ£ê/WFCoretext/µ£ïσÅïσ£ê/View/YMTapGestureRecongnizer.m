//
//  YMTapGestureRecongnizer.m
//  WFCoretext
//
//  Created by 阿虎 on 14/11/3.
//  Copyright (c) 2014年 tigerwf. All rights reserved.
//

#import "YMTapGestureRecongnizer.h"

@implementation YMTapGestureRecongnizer

@end
