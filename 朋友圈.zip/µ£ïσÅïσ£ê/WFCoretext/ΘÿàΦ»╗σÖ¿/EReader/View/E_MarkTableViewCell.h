//
//  E_MarkTableViewCell.h
//  WFReader
//
//  Created by 阿虎 on 15/3/2.
//  Copyright (c) 2015年 tigerwf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface E_MarkTableViewCell : UITableViewCell

@property (nonatomic,strong) UILabel *chapterLbl;
@property (nonatomic,strong) UILabel *timeLbl;
@property (nonatomic,strong) UILabel *contentLbl;

@end
